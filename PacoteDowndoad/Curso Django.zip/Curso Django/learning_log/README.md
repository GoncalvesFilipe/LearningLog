# learning_log
study project in Django
